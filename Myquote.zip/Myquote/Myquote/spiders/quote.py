import scrapy
import re
from Myquote.items import MyquoteItem


class QuoteSpider(scrapy.Spider):
    name = 'quote'
    allowed_domains = ['quotes.toscrape.com']
    start_urls = ['http://quotes.toscrape.com/']

    def parse(self, response):
        quotes = response.css('.quote')
        for quote in quotes:
            text = quote.css('.text::text').extract_first()
            author = quote.css('.author::text').extract_first()  
            tags = quote.css('.tags .tag::text').extract()
            link=quote.css('::attr(href)').extract_first()
            url_author=response.urljoin(link)
            item = MyquoteItem(text=text,author=author,tags=tags)
            yield scrapy.Request(url=url_author,meta={'item':item},callback=self.parse_authordata)
        # for href in response.css(r"div[class='quote'] a[href*='author']::attr(href)").extract():
        #     item = QuotetutorialItem()
        #     url=response.urljoin(href)
        #     print(url)
        #     born=scrapy.Request(url=url,meta={'item':item},callback=self.parse_authordata)
        #     print(born)
        #     yield born
        #     yield item
        next = response.css('.pager .next a::attr(href)').extract_first()
        url = response.urljoin(next)
        yield scrapy.Request(url=url, callback=self.parse)

    def parse_authordata(self,response):
        details=response.css('.author-details')
        date=details.css('.author-born-date::text').extract_first().split(',')
        date_day=date[0].split()[1];date_month=date[0].split()[0];date_year=date[1]
        location=response.css('.author-born-location::text').extract_first()
        location=re.sub(r'(in)',"",location)
        loc_city=location.split(',')[:-1];loc_country=location.split(',')[-1]
        item=response.meta['item']
        item['date_day']=date_day
        item['date_month']=date_month
        item['date_year']=date_year
        item['loc_city']=loc_city
        item['loc_country']=loc_country
        return item
 

