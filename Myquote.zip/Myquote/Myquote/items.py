# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class MyquoteItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    text=scrapy.Field()
    author=scrapy.Field()
    tags=scrapy.Field()
    date_day=scrapy.Field()
    date_month=scrapy.Field()
    date_year=scrapy.Field()
    loc_city=scrapy.Field()
    loc_country=scrapy.Field()